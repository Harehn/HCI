// content.js
console.log('Extension loaded.');
console.log('Applying colors...');

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === 'applyColors') {
    adjustColors();
  }
});

function adjustColors() {
  // Map of color code changes
  const colorMap = {
    '#357A32': '#62D26F',
    '#CA3120': '#EB384F',
    '#F7634D': '#FDAE33',
    '#EDF5FF': '#8D9F9B',

    // Add more color code changes as needed
  };

  // Change colors based on the map
  for (const [oldColor, newColor] of Object.entries(colorMap)) {
    replaceColors(oldColor, newColor);
  }

  // Save current color adjustments to storage
  chrome.storage.sync.set({
    colorMap
  });
}

function replaceColors(oldColor, newColor) {
  document.body.innerHTML = document.body.innerHTML.replace(
    new RegExp(oldColor, 'g'), newColor
  );
}

