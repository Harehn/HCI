// popup.js
document.addEventListener('DOMContentLoaded', function() {
  document.getElementById('applyColors').addEventListener('click', function() {
    chrome.runtime.sendMessage({ action: 'applyColors' });
  });

  // Request color changes from the background script
  chrome.runtime.sendMessage({ action: 'getColorChanges' });
});
