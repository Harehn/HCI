chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  console.log('Received message:', message);

  if (message.action === 'applyColors') {
    console.log('Applying colors...');
    // Add logic to apply colors here
  } else if (message.action === 'getColorChanges') {
    console.log('Fetching color changes...');
    // Simulate fetching color changes
    const colorMap = { '#357A32': '#62D26F', '#CA3120': '#EB384F', '#F7634D': '#8D9F9B' };
    chrome.runtime.sendMessage({ action: 'displayColorChanges', colorMap });
  }
});
